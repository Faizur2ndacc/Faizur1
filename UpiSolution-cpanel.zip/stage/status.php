<?php
$arr = array("status"=>'FAILED', "message"=>'Testing Status Not Required');
echo json_encode($arr);
?>

<?php
error_reporting(0);
$token = 'd9fe71-bfddea-d2ss1-b76n57-a2e52e'; // Your Token, (Url:http://example.com/Settings).
$secret = 'rDffdze'; // Your Secret Key, (Url:http://example.com/Settings).
$AHKWEB_ENVIRONMENT = 'PROD'; // PROD, TEST
?>